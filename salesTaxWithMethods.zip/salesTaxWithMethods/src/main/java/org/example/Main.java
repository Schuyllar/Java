package org.example;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

    public static double inputPurchasePrice() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the purchase price: ");
        double price = 0.0;
        try {
            price = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number.");
            return inputPurchasePrice();
        }
        return price;
    }

    public static double calculateTax(double price, double taxRate) {
        return price * taxRate;
    }

    public static double calculateTotal(double price, double tax) {
        return price + tax;
    }

    public static void displayTotals(double purchasePrice, double stateTax, double countyTax, double totalTax, double totalPrice) {
        DecimalFormat df = new DecimalFormat("0.00");

        System.out.printf("Purchase Price: $%s\n", df.format(purchasePrice));
        System.out.printf("State Tax: $%s\n", df.format(stateTax));
        System.out.printf("County Tax: $%s\n", df.format(countyTax));
        System.out.printf("Total Tax: $%s\n", df.format(totalTax));
        System.out.printf("Total Price: $%s\n", df.format(totalPrice));
    }

    public static void main(String[] args) {
        double purchasePrice = inputPurchasePrice();

        double stateTaxRate = 0.06;
        double countyTaxRate = 0.02;

        double stateTax = calculateTax(purchasePrice, stateTaxRate);
        double countyTax = calculateTax(purchasePrice, countyTaxRate);
        double totalTax = stateTax + countyTax;
        double totalPrice = calculateTotal(purchasePrice, totalTax);

        displayTotals(purchasePrice, stateTax, countyTax, totalTax, totalPrice);
    }
}
